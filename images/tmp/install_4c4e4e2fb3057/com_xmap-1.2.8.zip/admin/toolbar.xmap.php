<?php
/**
 * $Id: toolbar.xmap.php 10 2008-09-20 22:36:33Z guilleva $
 * $LastChangedDate: 2008-09-20 17:36:33 -0500 (Sat, 20 Sep 2008) $
 * $LastChangedBy: guilleva $
 * Xmap by Guillermo Vargas
 * a sitemap component for Joomla! CMS (http://www.joomla.org)
 * Author Website: http://joomla.vargas.co.cr
 * Project License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

