<?php

/**
* IE8 Compatibility Mambot
* Author: Jeremy.J <joly.jeremy@gmail.com>
* Copyright (C) 2009 All Rights Reserved
*/


// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

$_MAMBOTS->registerFunction( 'onAfterStart', 'botIE8Compatibility' );


function botIE8Compatibility()
{
    global $database, $mainframe;
    
    // Get mambot parameters
	$query = "SELECT id FROM #__mambots WHERE element = 'ie8_compatibility' AND folder = 'system'";
	$database->setQuery( $query );
	$id = $database->loadResult();
	$mambot = new mosMambot( $database );
	$mambot->load( $id );
	$param =& new mosParameters( $mambot->params );

    // Get plugin parameters
    $mode = $param->get('compatibility_mode', 'EmulateIE7');
    $method = $param->get('method', 'meta');


    switch($method){
        case 'meta':
            $mainframe->addCustomHeadTag('<meta http-equiv="X-UA-Compatible" content="IE=' . $mode . '" />');
            break;
            
        case 'header':
            header('X-UA-Compatible: IE=' . $mode);
            break;
    }
        
}